# -*- coding: utf-8 -*-
"""
Created on Fri Apr 10 23:42:33 2015

@author: 551594
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Apr 10 15:25:10 2015

@author: 551594
"""

import pandas as pd
import numpy as np
import matplotlib.pylab as plt

# Need to call data and merge files to make one dataset
# Read key.csv into a DataFrame called 'key'
key = pd.read_csv('../data/key.csv')
# Read weather.csv into a Dataframe called 'weather'
weather = pd.read_csv('../data/weather.csv')
# Read train.csv into a Dataframe called 'train'
train = pd.read_csv('../data/train.csv')

# Successful Merge of the data together using class notes
train2 = pd.merge(train, key, on='store_nbr', how = 'left')

# Observe the new weather merged columns as a check
train2.head()

# Unsuccessful Merge of the data together using class notes due to 'memory error'
weather2= pd.merge(train2, weather, on=['date', 'station_nbr'], how = 'left')
#created 'MemoryError'  Need to find a way to reduce the size of weather2

# Observe the new weather merged columns as a check, didnt work bc above
weather2.head()

train.item_nbr.value_counts()    # trying to see which ones are more common, all returning 41600 values
train2.item_nbr.value_counts() 

###########################################################
#Haven't really made it work past this point, goal is to break data set into one product, test that, and apply to all products
#Just put down pieces of code from previous classes I think I will need to do the above
###########################################################
# Fill in missing values with the mean value 
# First, Check for missing values in all columns
weather2.describe()
weather2.applymap(lambda x: x=='M')


# fill in missing values with mean
age_mean = d.Age.mean()

d.Age.fillna(value= age_mean, inplace=True)
d.fillna(age_mean)

#Need to identify a defined weather event within dataframe which is defined as any day in which more than an inch of rain or two inches of snow was observed. 

train2['Event'] = (train2['preciptotal']>=1) | (d['Age']>30)
d.head()



#Reduce dataframe to a sample item number using logical filtering

train2[train2.item_nbr == 7]

# split into training and testing sets
from sklearn.cross_validation import train_test_split
X_train, X_test, y_train, y_test = train_test_split(train2, train2.label, random_state=1)
X_train.shape
X_test.shape





