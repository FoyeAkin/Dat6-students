# -*- coding: utf-8 -*-
"""
Created on Tue Mar 24 22:15:11 2015

@author: Tom Bailey
"""

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.cross_validation import train_test_split
from datetime import datetime
import numpy as np
from sklearn.cross_validation import cross_val_score

#Read data into a dataframe using pandas and examine columns
data = pd.read_csv('..\\Data\\train.csv')
data.info()

#Open Date is currently an object dtype; convert it to a datetime dtype
#using pandas' to_datetime method 
data['Open Date'] = pd.to_datetime(data['Open Date'])

#Open Date by itself may not be helpful for our regression; instead, it seems
#more likely that the number of days in operation may be a better predictor of 
#a restaurant's annual revenue. 

#To do this, let's create a datetime variable with very end of FY2014, which
#we will use this to calculate the number of days that each restaurant has been open
FY2014End = datetime(2014,12,31)
data['days_open'] = data['Open Date'].apply(lambda x: (FY2014End - x).days)

#Convert City Group (Big, Other) and Type (Inline, Food Court, or Drive Thru)
#to dummy variables
city_grp_dummies = pd.get_dummies(data['City Group'], prefix='city_group').iloc[:, 1:]
type_dummies = pd.get_dummies(data['Type'], prefix='type').iloc[:, 1:]

#Lets do a scatter plot of revenue vs. days open to see if there is a correlation
plt.scatter(data.days_open, data.revenue, alpha=0.7)
plt.xlabel('Days Open')
plt.ylabel('Annual Revenue')

#0 indicates Big City, 1 Other; scatter plot
plt.scatter(city_grp_dummies.city_group_Other, data.revenue, alpha=0.7)
plt.xlabel('Big City(0) vs Other(1)')
plt.ylabel('Annual Revenue')

#1 indicates Food Court, 0 is either Inline or Drive Thru; scatter plot
plt.scatter(type_dummies.type_FC, data.revenue, alpha=0.7)
plt.xlabel('Other(0) vs FC(1)')
plt.ylabel('Annual Revenue')

#1 indicates InLine, 0 is either Food Court or Drive Thru; scatter plot
plt.scatter(type_dummies.type_IL, data.revenue, alpha=0.7)
plt.xlabel('Other(0) vs IL(1)')
plt.ylabel('Annual Revenue')


#Store all numeric data in dfNumData dataframe; this is what we actually need
#for the regression
dfNumData = pd.concat([data['days_open'], city_grp_dummies, type_dummies, data.iloc[:,5:43]],axis=1)

# Split the numeric data into train and test sets
train, test = train_test_split(dfNumData, test_size=0.3)

# Convert them back into dataframes, for convenience
train = pd.DataFrame(data=train, columns=dfNumData.columns)
test = pd.DataFrame(data=test, columns=dfNumData.columns)


def linear_reg(trainData, testData, regAllData):
    mlm = LinearRegression()
    mlm.fit(trainData, train['revenue'])

    scores = cross_val_score(mlm, regAllData, dfNumData['revenue'], cv=10, scoring='mean_squared_error')
    aveRMSE = np.mean(np.sqrt(-scores))  
    return aveRMSE    
    
def test_combos(lstCols):
    regTrainData = pd.concat([train.iloc[:,0:4], train[lstCols]] , axis=1)
    regTestData = pd.concat([test.iloc[:,0:4], test[lstCols]] , axis=1)
    regAllData = pd.concat([dfNumData.iloc[:,0:4], dfNumData[lstCols]] , axis=1)
    aveRMSE = linear_reg(regTrainData, regTestData, regAllData)
    return aveRMSE

#Try regression with everything
#Ave RMSE = 3569327.2985336548
linear_reg(train.iloc[:,:-1], test.iloc[:,:-1], dfNumData.iloc[:,:-1])

#Try regression with just city group type and type of establishment ('IL', 'FC', 'DT')
#Ave RMSE = 9.58564195308e+18
linear_reg(train.iloc[:,1:4], test.iloc[:,1:4], dfNumData.iloc[:,1:4])

#Try regression with just days open, city group type, and type of establishment ('IL', 'FC', 'DT')
#Ave RMSE = 2303897.4013288841
#Best model so far
linear_reg(train.iloc[:,0:4], test.iloc[:,0:4], dfNumData.iloc[:,0:4])

#Loop through every column of demographic data and add to previous model
import itertools

#Smallest RMSE is 2285908.7316228701 for combo of P25 and P32
dctRMSE2 = {}
for i in itertools.combinations(range(1,38), 2):
    print i
    lstCols = ['P' + str(i[x]) for x in range(0, 2)]
    dctRMSE2[i] = test_combos(lstCols)
    
min(dctRMSE2, key=dctRMSE2.get)
min(dctRMSE2.itervalues())

#Smallest RMSE is 2262813.5231390675 for combo of P23, P25, and P32      
dctRMSE3 = {}       
for i in itertools.combinations(range(1,38), 3):
    print i
    lstCols = ['P' + str(i[x]) for x in range(0, 3)]
    dctRMSE3[i] = test_combos(lstCols)
    
min(dctRMSE3, key=dctRMSE3.get)
min(dctRMSE3.itervalues())
    
    
#Smallest RMSE is 2262813.5231390675 (exactly the same as with 3) 
#for combo of P23, P25, P32, and P37 
dctRMSE4 = {}       
for i in itertools.combinations(range(1,38), 4):
    print i
    lstCols = ['P' + str(i[x]) for x in range(0, 3)]
    dctRMSE4[i] = test_combos(lstCols)
        
min(dctRMSE4, key=dctRMSE4.get)
min(dctRMSE4.itervalues())       
        
#Smallest RMSE is 2262813.5231390675 (exactly the same as with 3 and 4) 
#for combo of P23, P25, P32, P34, and P37         
dctRMSE5 = {}       
for i in itertools.combinations(range(1,38), 5):
    print i
    lstCols = ['P' + str(i[x]) for x in range(0, 3)]
    dctRMSE5[i] = test_combos(lstCols)        
  
min(dctRMSE5, key=dctRMSE5.get)
min(dctRMSE5.itervalues())        
        
#P23, P25, and P32 help lower the ave RMSE slightly; let's use scatterplots to examine
#relationship of each of these variable to annual revenue
plt.scatter(data.P23, data.revenue, alpha=0.7)
plt.xlabel('P23')
plt.ylabel('Annual Revenue')

plt.scatter(data.P25, data.revenue, alpha=0.7)
plt.xlabel('P25')
plt.ylabel('Annual Revenue')

plt.scatter(data.P32, data.revenue, alpha=0.7)
plt.xlabel('P32')
plt.ylabel('Annual Revenue')

#Let's try out the regression with the following variables: days_open, city group,
#type, P23, P25, and P32
trainSubset = pd.concat([train.iloc[:,0:4], train[['P23','P25','P32']]] , axis=1)
testSubset = pd.concat([test.iloc[:,0:4], test[['P23','P25','P32']]] , axis=1)

mlm = LinearRegression()
mlm.fit(trainSubset, train['revenue'])

for i in zip(trainSubset.columns, mlm.coef_):
    print i[0], i[1]

pred = mlm.predict(testSubset)

dfActVsPred = pd.concat([test['revenue'], pd.DataFrame(data=pred, columns=['predicted_rev'])],axis=1)
dfActVsPred['residuals'] = dfActVsPred['predicted_rev'] - dfActVsPred['revenue']

plt.scatter(dfActVsPred['predicted_rev'], dfActVsPred['residuals'], alpha=0.7)
plt.xlabel("Predicted rev")
plt.ylabel("Residuals")

#This part is using the model created above to make predictions for revenue based
#on the official test data for this competition. I didn't use this before because
#there would be no way to see how far off I was (that's the point of the competition)
########################################################################
realTestSet = pd.read_csv('..\\Data\\test.csv')
realTestSet.info()
realTestSet['Open Date'] = pd.to_datetime(realTestSet['Open Date'])

FY2014End = datetime(2014,12,31)
realTestSet['days_open'] = realTestSet['Open Date'].apply(lambda x: (FY2014End - x).days)

realtest_city_grp_dummies = pd.get_dummies(realTestSet['City Group'], prefix='city_group').iloc[:, 1:]
real_test_type_dummies = pd.get_dummies(realTestSet['Type'], prefix='type').iloc[:, 1:]

dfNumDataRealTest = pd.concat([realTestSet['days_open'], realtest_city_grp_dummies, real_test_type_dummies, realTestSet.iloc[:,5:43]],axis=1)

realTestSubset = pd.concat([dfNumDataRealTest.iloc[:,0:4], dfNumDataRealTest[['P23','P25','P32']]] , axis=1)

realPred = mlm.predict(realTestSubset)
dfRealPreds = pd.DataFrame(data=realPred, columns=['Prediction'])
dfRealPreds.index.name = 'Id'

dfRealPreds.to_csv('..\\Submissions\\Submission20150409.csv')